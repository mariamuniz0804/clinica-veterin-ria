"""
Sistema Veterinário Vida Pet - Aplicação Flask
Desenvolvido para fins educacionais

Este arquivo é o ponto de entrada principal da aplicação Flask.
Ele contém todas as rotas e a lógica de negócio do sistema.

EXPLICAÇÃO PARA INICIANTES:
- Flask é um framework web leve para Python
- Uma "rota" é um caminho que o usuário acessa no navegador (ex: /pets, /agendar)
- Cada rota está associada a uma função que é executada quando o usuário acessa aquele caminho
- O Flask usa o conceito de "templates" para separar a lógica (Python) da apresentação (HTML)
"""

# Importando as bibliotecas necessárias do Flask
from flask import Flask, render_template, request, redirect, url_for, flash
import datetime
import random

# Criando a aplicação Flask
# EXPLICAÇÃO: Esta linha cria uma instância do Flask, que é o nosso aplicativo web
app = Flask(__name__)
app.secret_key = 'vidapet2025'  # Chave necessária para mensagens flash (feedback ao usuário)

# Como não estamos usando banco de dados, vamos usar listas para armazenar os dados
# EXPLICAÇÃO: Estas listas funcionam como "tabelas" temporárias que existem apenas enquanto o programa está rodando
# Lista para armazenar os pets cadastrados
pets = [
    {
        'id': 1,
        'codigo': 'P001',
        'nome': 'Rex',
        'nome_tutor': 'João Silva',
        'raca': 'Labrador',
        'peso': 25.5,
        'telefone_tutor': '(11) 98765-4321',
        'sexo': 'Macho'
    },
    {
        'id': 2,
        'codigo': 'P002',
        'nome': 'Luna',
        'nome_tutor': 'Maria Oliveira',
        'raca': 'Persa',
        'peso': 4.2,
        'telefone_tutor': '(11) 91234-5678',
        'sexo': 'Fêmea'
    }
]

# Lista para armazenar as consultas agendadas
consultas = [
    {
        'id': 1,
        'codigo': 'C001',
        'nome_animal': 'Rex',
        'nome_tutor': 'João Silva',
        'data_horario': '25/05/2025 14:30',
        'sintomas': 'Tosse e espirros',
        'telefone': '(11) 98765-4321',
        'email': 'joao@email.com',
        'especie': 'Cachorro'
    }
]

# Rota para a página inicial
# EXPLICAÇÃO: O decorador @app.route define qual URL ativa esta função
@app.route('/')
def home():
    """
    Renderiza a página inicial do sistema
    
    EXPLICAÇÃO: 
    - render_template é uma função do Flask que combina um arquivo HTML com dados Python
    - Ela procura o arquivo HTML na pasta 'templates'
    """
    return render_template('index.html')

# Rota para listar todos os pets
@app.route('/pets')
def listar_pets():
    """
    Renderiza a página que lista todos os pets cadastrados
    
    EXPLICAÇÃO:
    - Estamos passando a lista 'pets' para o template
    - No template, podemos acessar esta lista e mostrar os dados na página
    """
    return render_template('pets.html', pets=pets)

# Rota para o formulário de cadastro de pet (GET) e para processar o cadastro (POST)
# EXPLICAÇÃO: Esta rota aceita dois métodos HTTP diferentes:
# - GET: quando o usuário acessa a página normalmente
# - POST: quando o usuário envia o formulário
@app.route('/pet/cadastrar', methods=['GET', 'POST'])
def cadastrar_pet():
    """
    GET: Exibe o formulário de cadastro de pet
    POST: Processa o formulário e adiciona o pet à lista
    
    EXPLICAÇÃO:
    - request.method nos diz se é GET ou POST
    - request.form contém os dados enviados pelo formulário
    - flash é usado para mostrar mensagens de feedback ao usuário
    - redirect e url_for são usados para redirecionar o usuário para outra página
    """
    if request.method == 'POST':
        # Gerando um ID único para o novo pet
        # EXPLICAÇÃO: max() encontra o maior ID existente e adiciona 1
        novo_id = max([pet['id'] for pet in pets], default=0) + 1
        
        # Gerando um código único para o novo pet
        # EXPLICAÇÃO: zfill(3) garante que o número tenha 3 dígitos (ex: 001, 002)
        novo_codigo = f"P{str(novo_id).zfill(3)}"
        
        # Obtendo os dados do formulário
        # EXPLICAÇÃO: request.form.get() obtém o valor de um campo do formulário
        nome = request.form.get('nome')
        nome_tutor = request.form.get('nome_tutor')
        raca = request.form.get('raca')
        peso = float(request.form.get('peso', 0))
        telefone_tutor = request.form.get('telefone_tutor')
        sexo = request.form.get('sexo', 'Não informado')
        
        # Criando o dicionário do novo pet
        # EXPLICAÇÃO: Um dicionário é uma estrutura de dados com pares chave-valor
        novo_pet = {
            'id': novo_id,
            'codigo': novo_codigo,
            'nome': nome,
            'nome_tutor': nome_tutor,
            'raca': raca,
            'peso': peso,
            'telefone_tutor': telefone_tutor,
            'sexo': sexo
        }
        
        # Adicionando o novo pet à lista
        pets.append(novo_pet)
        
        # Adicionando uma mensagem de sucesso
        # EXPLICAÇÃO: flash mostra uma mensagem temporária para o usuário
        flash('Pet cadastrado com sucesso!', 'success')
        
        # Redirecionando para a lista de pets
        # EXPLICAÇÃO: redirect redireciona o usuário para outra página
        # url_for gera a URL para uma função específica (neste caso, listar_pets)
        return redirect(url_for('listar_pets'))
    
    # Se for uma requisição GET, apenas renderiza o formulário
    return render_template('cadastrar_pet.html')

# Rota para editar um pet existente
@app.route('/pet/editar/<int:id>', methods=['GET', 'POST'])
def editar_pet(id):
    """
    GET: Exibe o formulário de edição com os dados do pet
    POST: Processa o formulário e atualiza os dados do pet
    
    EXPLICAÇÃO:
    - <int:id> na rota captura um número da URL e passa como parâmetro para a função
    - next() com um gerador (expressão for) encontra o primeiro item que satisfaz a condição
    """
    # Encontrando o pet pelo ID
    # EXPLICAÇÃO: Esta linha procura um pet na lista que tenha o ID igual ao fornecido
    pet = next((p for p in pets if p['id'] == id), None)
    
    # Se o pet não existir, redireciona para a lista
    if pet is None:
        flash('Pet não encontrado!', 'error')
        return redirect(url_for('listar_pets'))
    
    if request.method == 'POST':
        # Atualizando os dados do pet
        pet['nome'] = request.form.get('nome')
        pet['nome_tutor'] = request.form.get('nome_tutor')
        pet['raca'] = request.form.get('raca')
        pet['peso'] = float(request.form.get('peso', 0))
        pet['telefone_tutor'] = request.form.get('telefone_tutor')
        pet['sexo'] = request.form.get('sexo', 'Não informado')
        
        # Adicionando uma mensagem de sucesso
        flash('Pet atualizado com sucesso!', 'success')
        
        # Redirecionando para a lista de pets
        return redirect(url_for('listar_pets'))
    
    # Se for uma requisição GET, renderiza o formulário com os dados do pet
    return render_template('editar_pet.html', pet=pet)

# Rota para excluir um pet
@app.route('/pet/excluir/<int:id>')
def excluir_pet(id):
    """
    Exclui um pet da lista pelo ID
    
    EXPLICAÇÃO:
    - enumerate() retorna o índice e o valor de cada item na lista
    - Usamos o índice para remover o item da lista com pets.pop(i)
    """
    # Encontrando o índice do pet na lista
    for i, pet in enumerate(pets):
        if pet['id'] == id:
            # Removendo o pet da lista
            pets.pop(i)
            flash('Pet excluído com sucesso!', 'success')
            break
    
    # Redirecionando para a lista de pets
    return redirect(url_for('listar_pets'))

# Rota para visualizar os detalhes de um pet
@app.route('/pet/<int:id>')
def visualizar_pet(id):
    """
    Exibe os detalhes de um pet específico
    
    EXPLICAÇÃO:
    - Semelhante à rota de edição, mas apenas para visualização
    """
    # Encontrando o pet pelo ID
    pet = next((p for p in pets if p['id'] == id), None)
    
    # Se o pet não existir, redireciona para a lista
    if pet is None:
        flash('Pet não encontrado!', 'error')
        return redirect(url_for('listar_pets'))
    
    # Renderizando a página de detalhes do pet
    return render_template('visualizar_pet.html', pet=pet)

# Rota para o formulário de agendamento de consulta (GET) e para processar o agendamento (POST)
@app.route('/agendar', methods=['GET', 'POST'])
def agendar_consulta():
    """
    GET: Exibe o formulário de agendamento de consulta
    POST: Processa o formulário e adiciona a consulta à lista
    
    EXPLICAÇÃO:
    - Muito similar à rota de cadastro de pet, mas para consultas
    """
    if request.method == 'POST':
        # Gerando um ID único para a nova consulta
        novo_id = max([consulta['id'] for consulta in consultas], default=0) + 1
        
        # Gerando um código único para a nova consulta
        novo_codigo = f"C{str(novo_id).zfill(3)}"
        
        # Obtendo os dados do formulário
        nome = request.form.get('nome')
        telefone = request.form.get('telefone')
        email = request.form.get('email')
        especie = request.form.get('especie')
        data_horario = request.form.get('data_horario')
        nome_pet = request.form.get('nome_pet')
        
        # Criando o dicionário da nova consulta
        nova_consulta = {
            'id': novo_id,
            'codigo': novo_codigo,
            'nome_animal': nome_pet,
            'nome_tutor': nome,
            'data_horario': data_horario,
            'sintomas': '',
            'telefone': telefone,
            'email': email,
            'especie': especie
        }
        
        # Adicionando a nova consulta à lista
        consultas.append(nova_consulta)
        
        # Adicionando uma mensagem de sucesso
        flash('Consulta agendada com sucesso!', 'success')
        
        # Redirecionando para a página inicial
        return redirect(url_for('home'))
    
    # Se for uma requisição GET, apenas renderiza o formulário
    return render_template('agendar.html')

# Rota para excluir uma consulta
@app.route('/consulta/excluir/<int:id>')
def excluir_consulta(id):
    """
    Exclui uma consulta da lista pelo ID
    
    EXPLICAÇÃO:
    - Funciona exatamente como a exclusão de pet
    """
    # Encontrando o índice da consulta na lista
    for i, consulta in enumerate(consultas):
        if consulta['id'] == id:
            # Removendo a consulta da lista
            consultas.pop(i)
            flash('Consulta cancelada com sucesso!', 'success')
            break
    
    # Redirecionando para a página inicial
    return redirect(url_for('home'))

# Rota para calcular a dosagem de medicamento
@app.route('/calcular/medicamento', methods=['GET', 'POST'])
def calcular_medicamento():
    """
    GET: Exibe o formulário para cálculo de medicamento
    POST: Calcula a dosagem com base no peso do animal
    
    EXPLICAÇÃO:
    - Aqui implementamos a fórmula: peso * 10 = dosagem em mg
    """
    resultado = None
    
    if request.method == 'POST':
        # Obtendo o peso do animal do formulário
        peso = float(request.form.get('peso', 0))
        
        # Calculando a dosagem (peso * 10)
        dosagem = peso * 10
        
        # Formatando o resultado
        resultado = f"Animal de {peso}kg = {dosagem}mg"
    
    # Renderizando a página de cálculo de medicamento
    return render_template('calcular_medicamento.html', resultado=resultado)

# Rota para calcular a quantidade de soro
@app.route('/calcular/soro', methods=['GET', 'POST'])
def calcular_soro():
    """
    GET: Exibe o formulário para cálculo de soro
    POST: Calcula a quantidade de soro com base no peso e altura do animal
    
    EXPLICAÇÃO:
    - Aqui implementamos a fórmula: (peso * 50) + (altura * 2) = quantidade em ml
    """
    resultado = None
    
    if request.method == 'POST':
        # Obtendo o peso e altura do animal do formulário
        peso = float(request.form.get('peso', 0))
        altura = float(request.form.get('altura', 0))
        
        # Calculando a quantidade de soro ((peso * 50) + (altura * 2))
        quantidade = (peso * 50) + (altura * 2)
        
        # Formatando o resultado
        resultado = f"Animal de {peso}kg e {altura}cm = {quantidade}ml"
    
    # Renderizando a página de cálculo de soro
    return render_template('calcular_soro.html', resultado=resultado)

# Executando a aplicação
# EXPLICAÇÃO: 
# - Este bloco só é executado quando rodamos este arquivo diretamente (python app.py)
# - debug=True ativa o modo de desenvolvimento, que mostra erros detalhados e recarrega
#   automaticamente quando o código é alterado
if __name__ == '__main__':
    app.run(debug=True)

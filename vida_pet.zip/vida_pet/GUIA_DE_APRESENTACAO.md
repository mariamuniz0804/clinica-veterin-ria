# GUIA DE APRESENTAÇÃO - SISTEMA VETERINÁRIO VIDA PET

Olá! Este guia vai te ajudar a apresentar o sistema Vida Pet para sua turma. Vou explicar como tudo funciona e dar dicas para você mostrar as partes mais legais do projeto.

## 1. COMO EXECUTAR O PROJETO

### Preparando o ambiente:
1. Abra o PyCharm e importe a pasta `vida_pet`
2. Crie um ambiente virtual:
   - Menu: `File > Settings > Project > Python Interpreter`
   - Clique no ícone de engrenagem > Add
   - Selecione "Virtual Environment" > OK
3. Instale as dependências:
   - Abra o terminal do PyCharm
   - Execute: `pip install -r requirements.txt`
4. Execute o projeto:
   - Clique com botão direito no arquivo `app.py`
   - Selecione "Run 'app'"
5. Acesse no navegador: `http://127.0.0.1:5000`

## 2. O QUE DESTACAR NA APRESENTAÇÃO

### 2.1 Estrutura do Projeto (5 minutos)
- **Mostre a organização das pastas:**
  ```
  vida_pet/
  ├── app.py                # Arquivo principal com rotas e lógica
  ├── requirements.txt      # Dependências do projeto
  ├── static/               # Arquivos estáticos
  │   ├── css/              # Estilos CSS
  │   └── img/              # Imagens
  └── templates/            # Templates HTML
  ```
- **Explique**: "Organizei o projeto seguindo as boas práticas do Flask, separando o código Python, os templates HTML e os arquivos estáticos."

### 2.2 Conexão Python + HTML (10 minutos)
- **Abra o arquivo `app.py` e mostre uma rota simples:**
  ```python
  @app.route('/')
  def home():
      return render_template('index.html')
  ```
- **Explique**: "Quando alguém acessa o site, o Flask processa a rota '/' e chama a função home(), que renderiza o template index.html."

- **Mostre uma rota que passa dados para o template:**
  ```python
  @app.route('/pets')
  def listar_pets():
      return render_template('pets.html', pets=pets)
  ```
- **Explique**: "Aqui estamos passando a lista de pets para o template, para que possamos mostrar os dados na página."

- **Abra o template `pets.html` e mostre como os dados são usados:**
  ```html
  {% for pet in pets %}
  <div class="pet-card">
      <h3>{{ pet.nome }}</h3>
      <!-- outros dados -->
  </div>
  {% endfor %}
  ```
- **Explique**: "O template usa a linguagem Jinja2 para criar HTML dinâmico. O loop 'for' percorre a lista de pets e cria um card para cada um."

### 2.3 Formulários e Processamento de Dados (10 minutos)
- **Mostre o formulário de cadastro de pet:**
  ```html
  <form action="{{ url_for('cadastrar_pet') }}" method="post">
      <!-- campos do formulário -->
  </form>
  ```
- **Explique**: "O formulário envia os dados para a rota 'cadastrar_pet' usando o método POST."

- **Mostre como os dados são processados:**
  ```python
  @app.route('/pet/cadastrar', methods=['GET', 'POST'])
  def cadastrar_pet():
      if request.method == 'POST':
          # obter dados do formulário
          nome = request.form.get('nome')
          # processar dados
          # ...
          return redirect(url_for('listar_pets'))
      return render_template('cadastrar_pet.html')
  ```
- **Explique**: "Quando o formulário é enviado, o Flask recebe os dados, processa e redireciona o usuário para outra página."

### 2.4 Cálculos Veterinários (5 minutos)
- **Mostre as rotas de cálculo:**
  ```python
  @app.route('/calcular/medicamento', methods=['GET', 'POST'])
  def calcular_medicamento():
      # ...
      if request.method == 'POST':
          peso = float(request.form.get('peso', 0))
          dosagem = peso * 10
          resultado = f"Animal de {peso}kg = {dosagem}mg"
      # ...
  ```
- **Explique**: "Implementei as fórmulas veterinárias conforme os requisitos. Por exemplo, para calcular a dosagem de medicamento, multiplicamos o peso do animal por 10."

### 2.5 CSS e Design Responsivo (5 minutos)
- **Mostre o arquivo CSS e destaque:**
  - Uso de variáveis CSS
  - Media queries para responsividade
  - Estilização dos formulários e cards

- **Demonstre a responsividade**: Redimensione a janela do navegador para mostrar como o site se adapta a diferentes tamanhos de tela.

## 3. DICAS PARA UMA BOA APRESENTAÇÃO

### Prepare-se antes:
1. **Teste tudo**: Execute o sistema e teste todas as funcionalidades antes da apresentação.
2. **Tenha exemplos prontos**: Prepare alguns dados para cadastrar durante a demonstração.
3. **Conheça o código**: Revise o código para poder explicar qualquer parte se perguntarem.

### Durante a apresentação:
1. **Comece pelo visual**: Mostre primeiro o site funcionando, depois explique o código.
2. **Demonstre o fluxo completo**: Cadastre um pet, edite, exclua, faça um cálculo.
3. **Destaque os pontos fortes**:
   - Organização do código
   - Mensagens de feedback ao usuário
   - Design responsivo
   - Separação entre backend e frontend

### Pontos técnicos para destacar:
1. **Rotas Flask**: Como as URLs são mapeadas para funções Python
2. **Templates Jinja2**: Como o HTML é gerado dinamicamente
3. **Armazenamento em listas**: Como os dados são guardados temporariamente
4. **Redirecionamentos**: Como o usuário é levado de uma página para outra

## 4. PERGUNTAS COMUNS E RESPOSTAS

**P: Como os dados são armazenados?**  
R: "Neste projeto, os dados são armazenados temporariamente em listas Python. Em um sistema real, usaríamos um banco de dados como MySQL ou SQLite."

**P: O que acontece quando o servidor é reiniciado?**  
R: "Como estamos usando listas em memória, os dados são perdidos quando o servidor é reiniciado. Em um sistema real, os dados ficariam salvos no banco de dados."

**P: Como adicionar mais funcionalidades?**  
R: "Para adicionar uma nova funcionalidade, precisamos criar uma nova rota no app.py, um novo template HTML e atualizar o CSS se necessário."

**P: O site é seguro?**  
R: "Este é um projeto educacional básico. Em um sistema real, precisaríamos implementar autenticação, validação de dados e outras medidas de segurança."

## 5. CONCLUSÃO

Lembre-se: o mais importante é mostrar que você entende como o sistema funciona! Não se preocupe se esquecer algum detalhe técnico - foque em explicar o fluxo do sistema e como as partes se conectam.

Boa apresentação! 😊
